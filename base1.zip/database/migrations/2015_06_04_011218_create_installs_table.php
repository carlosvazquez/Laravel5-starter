<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateInstallsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('installs', function(Blueprint $table) {
            $table->increments('id');
            $table->integer('os')->unique();
            $table->integer('user_id')->unsigned();
            $table->integer('area_id')->unsigned();
            $table->integer('division_id')->unsigned();
            $table->string('name');
            $table->string('telefono');
            $table->string('domicilio')->nullable();
            $table->integer('status_id')->unsigned();
            $table->dateTime('programado');
            $table->dateTime('reprogramado')->nullable();
            $table->integer('userupdate')->unsigned();
            $table->timestamps();
        });
    }


    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('installs');
    }
}
