<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;


class CreateCancelsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cancels', function(Blueprint $table) {
            $table->integer('install_id')->unsigned()->nullable();
            $table->foreign('install_id')->references('id')->on('installs')->onDelete('cascade');
            $table->boolean('cerrado')->default(0);
            $table->boolean('reag')->default(0);
            $table->boolean('mal_dto')->default(0);
            $table->boolean('subt')->default(0);
            $table->boolean('ducto_in')->default(0);
            $table->boolean('cancelado')->default(0);
            $table->boolean('etpno75')->default(0);
            $table->boolean('sin_senal')->default(0);
            $table->boolean('ftiempo')->default(0);
            $table->boolean('yainstalada')->default(0);
            $table->boolean('falla_ont')->default(0);
            $table->longText('comentarios')->nullable();
            $table->timestamps();
        });
    }


    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('cancels');
    }
}
