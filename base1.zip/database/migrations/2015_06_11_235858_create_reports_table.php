<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateReportsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('reports', function(Blueprint $table) {
            $table->integer('install_id')->unsigned()->nullable();
            $table->foreign('install_id')->references('id')->on('installs')->onDelete('cascade');
            $table->float('potencia')->nullable();
            $table->float('download')->nullable();
            $table->float('upload')->nullable();
            $table->boolean('dto')->default(0);
            $table->string('terminal', 50)->nullable();
            $table->string('ont', 100)->nullable();
            $table->enum('opcion', array('aerea', 'sub'))->default('aerea');
            $table->boolean('dist25')->default(0);
            $table->boolean('dist50')->default(0);
            $table->boolean('dist75')->default(0);
            $table->boolean('dist125')->default(0);
            $table->string('modemadsl', 50)->nullable();
            $table->boolean('ont_nueva')->default(0);
            $table->boolean('no_tiene')->default(0);
            $table->boolean('se_nego')->default(0);
            $table->string('proveedor', 100)->nullable();
            $table->string('factura', 100)->nullable();
            $table->string('contratista', 150)->nullable();
            $table->string('noempleado', 150)->nullable();
            $table->string('vsw_ont', 150)->nullable();
            $table->float('velupload')->nullable();
            $table->boolean('reportstatus')->default(0);
            $table->timestamps();
        });
    }










    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('reports');
    }
}
