<?php

use Illuminate\Database\Seeder;


class StatusTableSeeder extends Seeder {
    public function run() {
        DB::table('statuses')->insert(array(
            'name' => 'E',
            'slug' =>  'En proceso'
        ));
        DB::table('statuses')->insert(array(
            'name' => 'F',
            'slug' =>  'Confirmada'
        ));
        DB::table('statuses')->insert(array(
            'name' => 'A',
            'slug' =>  'Asignada'
        ));
        DB::table('statuses')->insert(array(
            'name' => 'R',
            'slug' =>  'Reprogramada'
        ));
        DB::table('statuses')->insert(array(
            'name' => 'C',
            'slug' =>  'Cancelada'
        ));

        DB::table('statuses')->insert(array(
            'name' => 'T',
            'slug' =>  'Completada'
        ));
        DB::table('statuses')->insert(array(
            'name' => 'X',
            'slug' =>  'Archivada'
        ));
    }

}