<?php

use Illuminate\Database\Seeder;


class RoleTableSeeder extends Seeder {
    public function run() {
        DB::table('roles')->insert(array(
            'name' => 'Administrador',
            'slug' => 'admin',
            'description' => 'Administrador general',
        ));
        DB::table('roles')->insert(array(
            'name' => 'Contralor',
            'slug' => 'contralor',
            'description' => 'Contralor de servicio',
        ));
        DB::table('roles')->insert(array(
            'name' => 'Supervisor',
            'slug' => 'supervisor',
            'description' => 'Supervisión de servicio',
        ));
        DB::table('roles')->insert(array(
            'name' => 'Técnico',
            'slug' => 'tecnico',
            'description' => 'Técnico de servicio',
        ));

    }

}
