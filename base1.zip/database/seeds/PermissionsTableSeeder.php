<?php

use Illuminate\Database\Seeder;


class PermissionsTableSeeder extends Seeder {
    public function run() {
        DB::table('permissions')->insert(array(
            'name' => 'Crear usuario',
            'slug' => 'create',
            'description' => 'Crear usuarios',
            'model' => 'App\User',
        ));
        DB::table('permissions')->insert(array(
            'name' => 'Leer usuarios',
            'slug' => 'index',
            'description' => 'Leer o listar usuarios',
            'model' => 'App\User',
        ));
        DB::table('permissions')->insert(array(
            'name' => 'Editar usuario',
            'slug' => 'edit',
            'description' => 'Editar usuarios',
            'model' => 'App\User',
        ));
        DB::table('permissions')->insert(array(
            'name' => 'Actualizar usuario',
            'slug' => 'update',
            'description' => 'Editar usuarios',
            'model' => 'App\User',
        ));
        DB::table('permissions')->insert(array(
            'name' => 'Borrar usuarios',
            'slug' => 'destroy',
            'description' => 'Borrar usuarios',
            'model' => 'App\User',
        ));


        DB::table('permissions')->insert(array(
            'name' => 'Borrar instalaciones',
            'slug' => 'destroy',
            'description' => 'Borrar instalaciones',
            'model' => 'App\Install',
        ));


        DB::table('permissions')->insert(array(
            'name' => 'Ver reportes',
            'slug' => 'index',
            'description' => 'Ver reportes',
            'model' => 'App\Reporte',
        ));


    }

}
