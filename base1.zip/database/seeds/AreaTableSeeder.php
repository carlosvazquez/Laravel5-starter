<?php

use Illuminate\Database\Seeder;


class AreaTableSeeder extends Seeder {
    public function run() {

        DB::table('areas')->insert(array(
            'name' => 'Tijuana',
        ));

        DB::table('areas')->insert(array(
            'name' => 'Ensenada',
        ));

        DB::table('areas')->insert(array(
            'name' => 'Mexicali',
        ));
    }

}
