<?php

use Illuminate\Database\Seeder;
use Carbon\Carbon;


class InstallTableSeeder extends Seeder {

    public function run() {

        DB::table('installs')->insert(array(
            'os' => '73494539634',
            'user_id' => '4',
            'area_id' => '1',
            'division_id' => '1',
            'name' => 'Tecnogama',
            'telefono' => '5512341200',
            'domicilio' => 'Terracota 23 int 34, Col. Bosques',
            'status_id' => '1',
            'programado' => Carbon::now()->toDateTimeString(),
            'reprogramado' => '',
            'userupdate' => '3',
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now()
        ));

        DB::table('installs')->insert(array(
            'os' => '73494539634',
            'user_id' => '4',
            'area_id' => '2',
            'division_id' => '1',
            'name' => 'Pegaso',
            'telefono' => '5512341200',
            'domicilio' => 'Olivos 2344, Col. Prados',
            'status_id' => '1',
            'programado' => Carbon::now()->toDateTimeString(),
            'reprogramado' => '',
            'userupdate' => '3',
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now()
        ));

        DB::table('installs')->insert(array(
            'os' => '73494539634',
            'user_id' => '4',
            'area_id' => '1',
            'division_id' => '1',
            'name' => 'Metalmec',
            'telefono' => '5512341200',
            'domicilio' => 'Torres 233 desp 3, Col. Viveros',
            'status_id' => '2',
            'programado' => Carbon::now()->toDateTimeString(),
            'reprogramado' => '',
            'userupdate' => '3',
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now()
        ));
        DB::table('installs')->insert(array(
            'os' => '73494539634',
            'user_id' => '4',
            'area_id' => '3',
            'division_id' => '1',
            'name' => 'Alibaba',
            'telefono' => '5512341200',
            'domicilio' => 'Villa 1234, Col. Granjas',
            'status_id' => '1',
            'programado' => Carbon::now()->toDateTimeString(),
            'reprogramado' => '',
            'userupdate' => '3',
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now()
        ));
        DB::table('installs')->insert(array(
            'os' => '73494539634',
            'user_id' => '4',
            'area_id' => '1',
            'division_id' => '1',
            'name' => 'hellokiti',
            'telefono' => '5512341200',
            'domicilio' => 'Ingenieros 2 Piso 2, Col. Lomas',
            'status_id' => '3',
            'programado' => Carbon::now()->toDateTimeString(),
            'reprogramado' => '',
            'userupdate' => '3',
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now()
        ));
        DB::table('installs')->insert(array(
            'os' => '73494539634',
            'user_id' => '4',
            'area_id' => '1',
            'division_id' => '1',
            'name' => 'Gamesa',
            'telefono' => '5512341200',
            'domicilio' => 'Trojes 423, Col. Residencial',
            'status_id' => '4',
            'programado' => Carbon::now()->toDateTimeString(),
            'reprogramado' => '',
            'userupdate' => '3',
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now()
        ));
        DB::table('installs')->insert(array(
            'os' => '73494539634',
            'user_id' => '4',
            'area_id' => '2',
            'division_id' => '1',
            'name' => 'Alpino',
            'telefono' => '5512341200',
            'domicilio' => 'Escutia 1223 desp 1, Col. Industrial',
            'status_id' => '6',
            'programado' => Carbon::now()->toDateTimeString(),
            'reprogramado' => '',
            'userupdate' => '3',
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now()
        ));
        DB::table('installs')->insert(array(
            'os' => '73494539634',
            'user_id' => '4',
            'area_id' => '1',
            'division_id' => '1',
            'name' => 'Loreal',
            'telefono' => '5512341200',
            'domicilio' => 'Del Bosque 55, Col. Petroleros',
            'status_id' => '2',
            'programado' => Carbon::now()->toDateTimeString(),
            'reprogramado' => '',
            'userupdate' => '3',
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now()
        ));
        DB::table('installs')->insert(array(
            'os' => '73494539634',
            'user_id' => '4',
            'area_id' => '3',
            'division_id' => '1',
            'name' => 'Transnacional de abarrotes',
            'telefono' => '5512341200',
            'domicilio' => 'Universo 122 piso 6, Col. Parque',
            'status_id' => '5',
            'programado' => Carbon::now()->toDateTimeString(),
            'reprogramado' => '',
            'userupdate' => '3',
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now()
        ));

    }

}