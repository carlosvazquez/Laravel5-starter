<?php

use Illuminate\Database\Seeder;


class DivisionTableSeeder extends Seeder {
    public function run() {

        DB::table('divisions')->insert(array(
            'name' => 'Telnor',
        ));

    }

}
