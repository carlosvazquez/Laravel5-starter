<div class="container">
    <div class="row">
        <div class="col-xs-12">
            @include('flash::message')
        </div>
    </div>
</div>