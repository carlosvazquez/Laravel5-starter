$(window).ready( function() {
    setInterval(function () {
        location.reload();}, 300000);
});