# Laravel5-starter
Codebase for starter project with Laravel 5
